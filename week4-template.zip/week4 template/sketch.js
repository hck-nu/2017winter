// Template for p5.js project

function setup() {

}

function draw() {

}
